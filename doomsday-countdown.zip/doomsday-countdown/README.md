# Doomsday Countdown

Home screen countdown widget with your own photo as the background.

- Pick any photo, a title and a date and time.
- Seconds tick live on the home screen.
- Resize the widget freely. It switches between 5 layouts:
  tiny (1 column), strip (1 row), small (2x2), wide (4x2), large (3+ rows).
- Add as many widgets as you like, each with its own photo and date.
- Tap a widget to edit it.

## Get the APK (no Android Studio needed)

1. Create a free GitHub repo and upload everything in this folder.
2. Open the **Actions** tab and wait for "Build APK" to finish (a few minutes).
3. Open **Releases**, tap **Latest APK**, download `app-debug.apk` and install it.
   (Allow "install unknown apps" for your browser if asked.)
4. Long-press the home screen, open Widgets, add **Doomsday Countdown**.

On Poco/MIUI, if the days number ever looks stale after a reboot, open the app once
and turn on Autostart for it in Settings.
