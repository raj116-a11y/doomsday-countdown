package com.doomsday.countdown;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * The countdown widget.
 *
 * Seconds tick by themselves: a Chronometer inside the widget counts down the
 * hours/minutes/seconds left in the current day, so no background service is
 * needed. The days number is refreshed by an alarm that fires exactly when the
 * day rolls over.
 *
 * The widget picks one of five layouts depending on how big the user resizes it.
 */
public class CountdownWidget extends AppWidgetProvider {

    static final String ACTION_TICK = "com.doomsday.countdown.TICK";

    private static final long DAY = 24L * 60L * 60L * 1000L;

    private static final int L_TINY = 0;   // 1 column wide: just the days
    private static final int L_STRIP = 1;  // 1 row tall: one line
    private static final int L_SMALL = 2;  // about 2x2
    private static final int L_WIDE = 3;   // about 4x2
    private static final int L_LARGE = 4;  // 3+ rows tall

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (ACTION_TICK.equals(action)) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                updateWidget(context, AppWidgetManager.getInstance(context), id);
            }
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            updateAll(context);
        } else {
            super.onReceive(context, intent);
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            updateWidget(context, mgr, id);
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager mgr, int id, Bundle newOptions) {
        // Called whenever the user resizes the widget.
        updateWidget(context, mgr, id);
    }

    @Override
    public void onDeleted(Context context, int[] ids) {
        for (int id : ids) {
            cancelTick(context, id);
            Store.clear(context, id);
        }
    }

    static void updateAll(Context context) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(context, CountdownWidget.class));
        for (int id : ids) {
            updateWidget(context, mgr, id);
        }
    }

    private static int pickLayoutType(AppWidgetManager mgr, int id) {
        Bundle o = mgr.getAppWidgetOptions(id);
        int w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        int h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110);
        if (w < 100) return L_TINY;
        if (h < 100) return L_STRIP;
        if (h >= 220) return L_LARGE;
        if (w >= 230) return L_WIDE;
        return L_SMALL;
    }

    static void updateWidget(Context ctx, AppWidgetManager mgr, int id) {
        int type = pickLayoutType(mgr, id);
        int layoutRes;
        switch (type) {
            case L_TINY:
                layoutRes = R.layout.widget_tiny;
                break;
            case L_STRIP:
                layoutRes = R.layout.widget_strip;
                break;
            case L_WIDE:
                layoutRes = R.layout.widget_wide;
                break;
            case L_LARGE:
                layoutRes = R.layout.widget_large;
                break;
            default:
                layoutRes = R.layout.widget_small;
                break;
        }

        RemoteViews rv = new RemoteViews(ctx.getPackageName(), layoutRes);

        long target = Store.getTarget(ctx, id);
        boolean configured = target != 0L;
        long now = System.currentTimeMillis();
        long remaining = configured ? target - now : 0L;
        boolean expired = configured && remaining <= 0L;
        boolean running = configured && !expired;
        long days = running ? remaining / DAY : 0L;
        long segment = running ? remaining - days * DAY : 0L; // time left within the current day

        // Background photo (or the default dark-red gradient).
        Bitmap photo = Store.loadPhoto(ctx, id);
        if (photo != null) {
            rv.setImageViewBitmap(R.id.bg, photo);
        } else {
            rv.setImageViewResource(R.id.bg, R.drawable.default_bg);
        }

        String daysText = configured ? String.format(Locale.US, "%03d", days) : "---";
        String label;
        if (!configured) {
            label = "TAP TO SET UP";
        } else if (expired) {
            label = "TIME'S UP";
        } else {
            label = days == 1L ? "DAY" : "DAYS";
        }

        if (type == L_STRIP) {
            String stripText = !configured ? "SET UP" : (expired ? "DONE" : daysText + "D");
            rv.setTextViewText(R.id.days, stripText);
        } else {
            rv.setTextViewText(R.id.days, daysText);
            rv.setTextViewText(R.id.label, label);
        }

        if (type == L_SMALL || type == L_WIDE || type == L_LARGE) {
            rv.setTextViewText(R.id.title, Store.getTitle(ctx, id));
        }

        if (type == L_LARGE) {
            String footer = "TAP TO SET UP";
            if (configured) {
                footer = "UNTIL " + new SimpleDateFormat("dd MMM yyyy  ·  HH:mm", Locale.getDefault())
                        .format(new Date(target)).toUpperCase(Locale.getDefault());
            }
            rv.setTextViewText(R.id.footer, footer);
        }

        if (type != L_TINY) {
            rv.setChronometerCountDown(R.id.timer, true);
            if (running) {
                rv.setChronometer(R.id.timer, SystemClock.elapsedRealtime() + segment, null, true);
            } else {
                rv.setChronometer(R.id.timer, SystemClock.elapsedRealtime(), null, false);
            }
        }

        // Tapping the widget opens the editor for this widget.
        Intent edit = new Intent(ctx, ConfigActivity.class);
        edit.setAction(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
        edit.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        edit.setData(Uri.parse("doomsday://widget/" + id));
        PendingIntent editPi = PendingIntent.getActivity(ctx, id, edit,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.root, editPi);

        mgr.updateAppWidget(id, rv);

        if (running) {
            // Wake up right after the current day-segment hits zero so the days number drops by one.
            scheduleTick(ctx, id, now + segment + 500L);
        } else {
            cancelTick(ctx, id);
        }
    }

    private static PendingIntent tickIntent(Context ctx, int id) {
        Intent i = new Intent(ctx, CountdownWidget.class);
        i.setAction(ACTION_TICK);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        i.setData(Uri.parse("doomsday://tick/" + id));
        return PendingIntent.getBroadcast(ctx, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void scheduleTick(Context ctx, int id, long atMillis) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = tickIntent(ctx, id);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        }
    }

    private static void cancelTick(Context ctx, int id) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(tickIntent(ctx, id));
    }
}
