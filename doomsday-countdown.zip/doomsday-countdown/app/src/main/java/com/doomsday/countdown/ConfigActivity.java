package com.doomsday.countdown;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;

/**
 * Setup screen. Opens when you add the widget, when you tap the widget,
 * and when you open the app from the app drawer.
 */
public class ConfigActivity extends Activity {

    private static final int REQ_PICK_PHOTO = 1001;
    private static final int MAX_PHOTO_SIDE = 1000;

    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private final Calendar cal = Calendar.getInstance();
    private Bitmap pendingPhoto;
    private boolean photoRemoved;

    private EditText titleInput;
    private Button dateBtn;
    private Button timeBtn;
    private ImageView preview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            widgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        View form = findViewById(R.id.form_group);
        View help = findViewById(R.id.help_group);

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            // Opened from the app drawer: show how to add the widget.
            form.setVisibility(View.GONE);
            help.setVisibility(View.VISIBLE);
            findViewById(R.id.add_btn).setOnClickListener(v -> requestPin());
            return;
        }

        // If the user backs out, the widget must not be added.
        setResult(RESULT_CANCELED, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));

        titleInput = findViewById(R.id.title_input);
        dateBtn = findViewById(R.id.date_btn);
        timeBtn = findViewById(R.id.time_btn);
        preview = findViewById(R.id.photo_preview);

        titleInput.setText(Store.getTitle(this, widgetId));

        long saved = Store.getTarget(this, widgetId);
        if (saved != 0L) {
            cal.setTimeInMillis(saved);
        } else {
            cal.add(Calendar.DAY_OF_YEAR, 30);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
        }

        Bitmap existing = Store.loadPhoto(this, widgetId);
        if (existing != null) {
            preview.setImageBitmap(existing);
        }
        refreshButtons();

        dateBtn.setOnClickListener(v -> new DatePickerDialog(
                this,
                (picker, y, m, d) -> {
                    cal.set(y, m, d);
                    refreshButtons();
                },
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
        ).show());

        timeBtn.setOnClickListener(v -> new TimePickerDialog(
                this,
                (picker, h, min) -> {
                    cal.set(Calendar.HOUR_OF_DAY, h);
                    cal.set(Calendar.MINUTE, min);
                    cal.set(Calendar.SECOND, 0);
                    cal.set(Calendar.MILLISECOND, 0);
                    refreshButtons();
                },
                cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
                DateFormat.is24HourFormat(this)
        ).show());

        findViewById(R.id.pick_btn).setOnClickListener(v -> pickPhoto());
        findViewById(R.id.clear_btn).setOnClickListener(v -> {
            pendingPhoto = null;
            photoRemoved = true;
            preview.setImageDrawable(null);
        });
        findViewById(R.id.save_btn).setOnClickListener(v -> save());
    }

    private void refreshButtons() {
        dateBtn.setText(DateFormat.getMediumDateFormat(this).format(cal.getTime()));
        timeBtn.setText(DateFormat.getTimeFormat(this).format(cal.getTime()));
    }

    private void pickPhoto() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Choose photo"), REQ_PICK_PHOTO);
        } catch (RuntimeException e) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_PHOTO || resultCode != RESULT_OK
                || data == null || data.getData() == null) {
            return;
        }
        try {
            Bitmap b = decodeScaled(data.getData(), MAX_PHOTO_SIDE);
            pendingPhoto = b;
            photoRemoved = false;
            preview.setImageBitmap(b);
        } catch (IOException | RuntimeException | OutOfMemoryError e) {
            Toast.makeText(this, "Couldn't open that photo", Toast.LENGTH_LONG).show();
        }
    }

    private void save() {
        String title = titleInput.getText().toString().trim();
        if (title.isEmpty()) title = "DOOMSDAY";

        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Store.save(this, widgetId, title, cal.getTimeInMillis());

        try {
            if (pendingPhoto != null) {
                Store.savePhoto(this, widgetId, pendingPhoto);
            } else if (photoRemoved) {
                Store.deletePhoto(this, widgetId);
            }
        } catch (IOException e) {
            Toast.makeText(this, "Couldn't save the photo", Toast.LENGTH_LONG).show();
        }

        CountdownWidget.updateWidget(this, AppWidgetManager.getInstance(this), widgetId);

        setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        finish();
    }

    private void requestPin() {
        AppWidgetManager mgr = AppWidgetManager.getInstance(this);
        if (mgr.isRequestPinAppWidgetSupported()) {
            mgr.requestPinAppWidget(new ComponentName(this, CountdownWidget.class), null, null);
        } else {
            Toast.makeText(this,
                    "Long-press your home screen, open Widgets, and pick Doomsday Countdown",
                    Toast.LENGTH_LONG).show();
        }
    }

    /** Decodes a picked photo, fixes its rotation and shrinks it so the widget stays light. */
    private Bitmap decodeScaled(Uri uri, int maxSide) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int longest = Math.max(bounds.outWidth, bounds.outHeight);
        if (longest <= 0) throw new IOException("Not an image");

        int sample = 1;
        while (longest / (sample * 2) >= maxSide) sample *= 2;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap decoded;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            decoded = BitmapFactory.decodeStream(in, null, opts);
        }
        if (decoded == null) throw new IOException("Could not read image");

        int rotation = 0;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in != null) {
                int o = new ExifInterface(in).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (o == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
                else if (o == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
                else if (o == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
            }
        } catch (IOException ignored) {
            // No rotation info: keep the photo as it is.
        }

        float scale = Math.min(1f, (float) maxSide / Math.max(decoded.getWidth(), decoded.getHeight()));
        if (rotation == 0 && scale == 1f) return decoded;

        Matrix m = new Matrix();
        m.postRotate(rotation);
        m.postScale(scale, scale);
        Bitmap out = Bitmap.createBitmap(decoded, 0, 0, decoded.getWidth(), decoded.getHeight(), m, true);
        if (out != decoded) decoded.recycle();
        return out;
    }
}
