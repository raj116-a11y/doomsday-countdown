package com.doomsday.countdown;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/** Per-widget settings (title, target time, photo). Every widget has its own. */
final class Store {

    private static final String PREFS = "doomsday";

    private Store() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String getTitle(Context c, int id) {
        return prefs(c).getString("title_" + id, "DOOMSDAY");
    }

    /** Target time in epoch millis, or 0 if this widget has not been set up yet. */
    static long getTarget(Context c, int id) {
        return prefs(c).getLong("target_" + id, 0L);
    }

    static void save(Context c, int id, String title, long targetMillis) {
        prefs(c).edit()
                .putString("title_" + id, title)
                .putLong("target_" + id, targetMillis)
                .apply();
    }

    static File photoFile(Context c, int id) {
        return new File(c.getFilesDir(), "bg_" + id + ".jpg");
    }

    static Bitmap loadPhoto(Context c, int id) {
        File f = photoFile(c, id);
        if (!f.exists()) return null;
        return BitmapFactory.decodeFile(f.getAbsolutePath());
    }

    static void savePhoto(Context c, int id, Bitmap bmp) throws IOException {
        try (FileOutputStream out = new FileOutputStream(photoFile(c, id))) {
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out);
        }
    }

    static void deletePhoto(Context c, int id) {
        File f = photoFile(c, id);
        if (f.exists()) //noinspection ResultOfMethodCallIgnored
            f.delete();
    }

    static void clear(Context c, int id) {
        prefs(c).edit().remove("title_" + id).remove("target_" + id).apply();
        deletePhoto(c, id);
    }
}
